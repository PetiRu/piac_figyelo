import yfinance as yf
import pandas as pd
from stocks import get_dax_stocks

def filter_stocks_by_stochastic():
    result = []
    for name, yf_ticker, tv_ticker in get_dax_stocks():
        try:
            df = yf.download(
                yf_ticker,
                start=(pd.Timestamp.today() - pd.DateOffset(months=6)),
                interval="1d",
                progress=False,
                auto_adjust=True
            )
            if df.empty:
                continue

            low14 = df['Low'].rolling(14).min()
            high14 = df['High'].rolling(14).max()
            k_percent = 100 * (df['Close'] - low14) / (high14 - low14)
            k_percent = k_percent.dropna()

            if k_percent.empty:
                continue

            last_k = float(k_percent.iloc[-1])  # biztos szám legyen

            if last_k <= 20:
                result.append((name, yf_ticker, tv_ticker, round(last_k, 2)))

        except Exception as e:
            print(f"[CHECK PANEL] Hiba {yf_ticker} lekérésekor: {e}")

    return result

