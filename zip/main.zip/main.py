import tkinter as tk
from tkinter import ttk
import threading
import time
from rules import filter_stocks_by_stochastic
import updater
import json
import os

SPLASH_DURATION = 5  # másodperc
VERSION_FILE = "version.json"

class ReszvenyFigyeloApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Részvény Figyelő")
        self.geometry("950x500")
        self.configure(bg="#ececec")

        # Splash screen a fő ablakban
        self.splash_label = tk.Label(self, text="Részvény Figyelő betöltése...", bg="#ececec", font=("Arial", 16))
        self.splash_label.pack(expand=True)
        self.progress = ttk.Progressbar(self, orient="horizontal", length=300, mode="determinate")
        self.progress.pack(pady=20)
        self.start_time = time.time()
        self.update_progress()

        # Updater flag
        self.updater_running = False

    def update_progress(self):
        elapsed = time.time() - self.start_time
        progress_value = min(int((elapsed / SPLASH_DURATION) * 100), 100)
        self.progress['value'] = progress_value
        self.update_idletasks()

        if elapsed >= SPLASH_DURATION:
            self.start_app()
        else:
            self.after(50, self.update_progress)

    def start_app(self):
        # splash eltávolítása
        self.splash_label.destroy()
        self.progress.destroy()

        # GUI létrehozása
        self.create_widgets()

        # updater thread indítása
        threading.Thread(target=self.run_updater, daemon=True).start()

    def create_widgets(self):
        # TreeView
        self.tree = ttk.Treeview(self, columns=("name","ticker","kvalue"), show="headings", height=20)
        self.tree.heading("name", text="Részvény neve")
        self.tree.heading("ticker", text="Yahoo ticker")
        self.tree.heading("kvalue", text="%K")
        self.tree.column("name", width=250)
        self.tree.column("ticker", width=100)
        self.tree.column("kvalue", width=50)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side=tk.LEFT, fill=tk.Y)
        self.tree.configure(yscrollcommand=scrollbar.set)

        # Sorok színezése
        self.tree.tag_configure('evenrow', background='#f2f2f2')
        self.tree.tag_configure('oddrow', background='#ffffff')

        # CMD log panel
        self.log_text = tk.Text(self, font=("Consolas",10), state="disabled", width=35, bg="#d9d9d9", fg="black")
        self.log_text.pack(side=tk.RIGHT, fill=tk.Y, padx=5, pady=5)

        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Indulás...")
        status_bar = tk.Label(self, textvariable=self.status_var, relief=tk.SUNKEN, anchor="w", bg="#d9d9d9")
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Menu
        menubar = tk.Menu(self)
        self.config(menu=menubar)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Frissítés", command=self.refresh_stocks)
        file_menu.add_separator()
        file_menu.add_command(label="Kilépés", command=self.destroy)
        menubar.add_cascade(label="Fájl", menu=file_menu)

        # Automatikus frissítés gomb
        auto_update_btn = tk.Button(self, text="Automatikus frissítés", command=self.run_updater, bg="#d9d9d9")
        auto_update_btn.pack(side=tk.TOP, pady=5)

    def log(self, msg, color=None):
        self.log_text.config(state="normal")
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state="disabled")
        if color == "red":
            print(f"\033[91m[CHECK PANEL] {msg}\033[0m")
        elif color == "green":
            print(f"\033[92m[CHECK PANEL] {msg}\033[0m")
        else:
            print(f"[CHECK PANEL] {msg}")

    def run_updater(self):
        if self.updater_running:
            self.log("Updater már fut.", "red")
            return
        self.updater_running = True
        self.log("Updater elindult...")
        updater.run_updater()
        # verzió olvasása a status barhoz
        if os.path.exists(VERSION_FILE):
            with open(VERSION_FILE, "r") as f:
                data = json.load(f)
            if data.get("update") == "available":
                self.status_var.set("Frissítés elérhető!")
            else:
                self.status_var.set("Legfrissebb verzió.")
        else:
            self.status_var.set("Legfrissebb verzió.")
        self.refresh_stocks()
        self.updater_running = False

    def refresh_stocks(self):
        self.log("Részvények lekérése...")
        filtered = filter_stocks_by_stochastic()
        self.tree.delete(*self.tree.get_children())
        if not filtered:
            self.log("Frissítés lefutott: 0 részvény talált.", "red")
            return
        for idx, (name, yf_ticker, tv_ticker, last_k) in enumerate(filtered):
            tag = 'evenrow' if idx % 2 == 0 else 'oddrow'
            self.tree.insert("", tk.END, values=(name, yf_ticker, f"{last_k:.2f}"), tags=(tag,))
        self.log(f"Frissítés lefutott: {len(filtered)} részvény talált.", "green")

if __name__ == "__main__":
    app = ReszvenyFigyeloApp()
    app.mainloop()

