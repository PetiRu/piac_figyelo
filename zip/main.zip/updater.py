import json
import os
import requests

GITHUB_VERSION_URL = "https://raw.githubusercontent.com/PetiRu/piac_figyelo/main/Pisti/version.json"

def get_local_version():
    if os.path.exists("version.json"):
        with open("version.json", "r") as f:
            data = json.load(f)
            return data.get("version", "0.0.0")
    return "0.0.0"

def get_github_version_info():
    try:
        response = requests.get(GITHUB_VERSION_URL)
        response.raise_for_status()
        data = response.json()
        github_version = data.get("version", "0.0.0")
        files = data.get("files", [])
        update_status = data.get("update", "no update")
        return github_version, files, update_status
    except Exception as e:
        print(f"[CHECK PANEL] Hiba a GitHub verzió lekérésekor: {e}")
        return "0.0.0", [], "no update"

def download_file(file_name):
    try:
        url = f"https://raw.githubusercontent.com/PetiRu/piac_figyelo/main/Pisti/{file_name}"
        r = requests.get(url)
        r.raise_for_status()
        with open(file_name, "wb") as f:
            f.write(r.content)
        print(f"[CHECK PANEL] {file_name} letöltve.")
    except Exception as e:
        print(f"[CHECK PANEL] Hiba a {file_name} letöltésekor: {e}")

def run_updater():
    local_version = get_local_version()
    github_version, github_files, update_status = get_github_version_info()

    print(f"[CHECK PANEL] Helyi verzió: {local_version}, GitHub verzió: {github_version}")

    if github_version > local_version and github_files:
        print("[CHECK PANEL] Frissítés elérhető!")
        for file in github_files:
            download_file(file)

        # update a local version.json
        with open("version.json", "w") as f:
            json.dump({"version": github_version, "update": "no update", "files": github_files}, f)
    else:
        print("[CHECK PANEL] Már a legfrissebb verzió:", local_version)

